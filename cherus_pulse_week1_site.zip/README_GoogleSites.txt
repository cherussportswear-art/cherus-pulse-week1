
Cherus Pulse Week1 - Site Package
--------------------------------

Files included:
- week1-cherus-pulse.html  (main HTML file)
- /images/nyayo-hero.jpg   (placeholder hero image)
- /images/titto.jpg        (placeholder player image)
- /images/ogwora.jpg
- /images/towett.jpg
- /images/odhiambo.jpg

HOW TO PUBLISH ON GOOGLE SITES (STEP-BY-STEP)
1. Host files: Upload the entire folder to Google Drive or a hosting provider (Netlify, GitHub Pages).
   - Preferred: Upload the zip to Google Drive and set sharing to 'Anyone with link' for images if embedding directly.
2. Create a new Google Site (sites.google.com).
3. Add a new page or select where you want the report.
4. Insert > Embed > Embed Code. Paste the contents of 'week1-cherus-pulse.html' into the embed box.
   - If the embed is blocked, upload the HTML to a public host (GitHub Pages) and use the published URL.
5. To embed images from Drive: Upload images to Google Drive, right-click > Get link > Change to 'Anyone with link' > Copy link.
   - Use the Drive image link in the HTML or replace with hosted URLs.
6. For Google Sheets live table: Insert > Sheets > select the sheet with standings. Place it where the table is needed.
7. For Fan Poll: Use Insert > Embed > paste StrawPoll or Google Forms URL.
8. Preview (top-right) > Test on mobile and desktop > Publish the site.

Notes:
- If Google Sites refuses to render the full HTML (common), use GitHub Pages or Netlify to host the page and embed the published URL in Google Sites.
- For WordPress or other CMS, upload the HTML as a page template or paste the HTML in a Custom HTML block.
